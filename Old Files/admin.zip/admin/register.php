<?php

require 'db.php';


$fname = $_POST['user_fname'];
$lname = $_POST['user_lname'];
$addr = $_POST['address'];
$num = $_POST['contact_no'];
$type = $_POST['user_role'];
$user = $_POST['user_name'];
$pass = $_POST['password'];

$sql = "SELECT user_name FROM user WHERE user_name = '$user'";
$res = $conn->query($sql);

$pass = $_POST['password'];
if ($_POST['password'] != $_POST['password2']) {
    $m = "Password not Match!";
    echo "
            <script type = 'text/javascript'>
                alert('$m');
                window.location.replace('index.php#toregister');
            </script>
         ";
} elseif ($res->num_rows > 0){
    $m = "Username already exist!";
    echo "
            <script type = 'text/javascript'>
                alert('$m');
                window.location.replace('index.php#toregister');
            </script>
         ";
}else {
    $sql = "INSERT INTO user(user_fname,user_lname,address,contact_no,user_role,user_name,password,status) VALUES 
                ('$fname','$lname','$addr','$num','$type','$user','$pass','pending')";

    $r = $conn->query($sql);
    if (!$r) {
        var_dump($conn->error);
        die;

        echo "
            <script type = 'text/javascript'>
                alert('$m');
                window.location.replace('index.php');
            </script>
         ";
    }

    $m = "Success!";
    echo "
            <script type = 'text/javascript'>
                alert('$m');
                window.location.replace('index.php');
            </script>
         ";
}

