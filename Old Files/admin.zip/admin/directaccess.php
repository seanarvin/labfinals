<html>
    <body>
        <h1> No Direct Access Allowed!</h1>

        <a href="index.php" >Home</a>
    </body>
</html>