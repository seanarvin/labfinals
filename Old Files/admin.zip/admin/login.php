<?php


require 'db.php';
session_start();



$user = $_POST['user_name'];
$pass = $_POST['password'];


$sql = "SELECT user_name,password,user_role,user_Id,status FROM user WHERE user_name = ? AND password = ?";
$st = $conn->prepare($sql);
$st->bind_param('ss',$user,$pass);
$st->execute();
$res = $st->get_result();
$r = $res->fetch_row();

if($res->num_rows > 0){
    if($r[4] == 'activated') {
        $_SESSION['user_name'] = $user;
        $_SESSION['user_role'] = $r[2];
        $_SESSION['id'] = $r[2];

        if ($r[2] == "Admin") {
            header('Location:dashboard.php');
        } elseif ($r[2] == "Service Provider") {
            header('Location: //cars2go.net:8080/ServiceProvider/requests.jsp?ayd=' . $r[3]);
        } elseif ($r[2] == "Client") {
            header('Location: //cars2go.net:2001/index/' . $r[3]);
        } else {
            $m = "Who Are You?!";
            echo "
            <script type = 'text/javascript'>
                alert('$m');
                window.location.replace('index.php');
            </script>
         ";
        }
    }else{
        $m = "User is not Activated,contact Administrator!";
        echo "
            <script type = 'text/javascript'>
                alert('$m');
                window.location.replace('index.php');
            </script>";
    }

}else{
    $m = "Wrong Credentials!";
    echo "
            <script type = 'text/javascript'>
                alert('$m');
                window.location.replace('index.php');
            </script>
         ";
}
